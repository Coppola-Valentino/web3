#include "pch.h"
#include "XivAlexanderCommon/Utils/Win32/LoadedModule.h"

#include "XivAlexanderCommon/Utils/Win32/Process.h"

Utils::Win32::LoadedModule::LoadedModule(const wchar_t* pwszFileName, DWORD dwFlags, bool bRequire)
	: Closeable<HMODULE, FreeLibrary>(LoadLibraryExW(pwszFileName, nullptr, dwFlags), Null) {
	if (!m_object && bRequire)
		throw Error("LoadLibraryExW({}, nullptr, 0x{:x})", pwszFileName, dwFlags);
}

Utils::Win32::LoadedModule::LoadedModule(const std::filesystem::path& path, DWORD dwFlags, bool bRequire)
	: LoadedModule(path.c_str(), dwFlags, bRequire) {
}

Utils::Win32::LoadedModule::LoadedModule(LoadedModule&& r) noexcept
	: Closeable(std::move(r)) {
}

Utils::Win32::LoadedModule::LoadedModule(const LoadedModule& r)
	: Closeable(r.m_bOwnership&& r.m_object ? LoadLibraryW(Process::Current().PathOf(r.m_object).c_str()) : r.m_object,
		r.m_bOwnership) {
	if (r.m_object && !m_object)
		throw Error("LoadLibraryW");
}

Utils::Win32::LoadedModule& Utils::Win32::LoadedModule::operator=(LoadedModule&& r) noexcept {
	if (this == &r)
		return *this;

	Clear();
	m_object = r.m_object;
	m_bOwnership = r.m_bOwnership;
	r.Detach();
	return *this;
}

Utils::Win32::LoadedModule& Utils::Win32::LoadedModule::operator=(const LoadedModule& r) {
	if (!r.m_bOwnership || !r.m_object) {
		Clear();
		m_object = r.m_object;
		m_bOwnership = r.m_bOwnership;
	} else {
		*this = LoadMore(r);
	}
	return *this;
}

Utils::Win32::LoadedModule& Utils::Win32::LoadedModule::operator=(std::nullptr_t) {
	Clear();
	return *this;
}

Utils::Win32::LoadedModule::~LoadedModule() = default;

Utils::Win32::LoadedModule Utils::Win32::LoadedModule::LoadMore(const LoadedModule & module) {
	return LoadedModule(module.PathOf().c_str(), 0, true);
}

std::filesystem::path Utils::Win32::LoadedModule::PathOf() const {
	return Process::Current().PathOf(*this);
}

std::filesystem::path Utils::Win32::LoadedModule::BaseName() const {
	std::wstring result;
	result.resize(PATHCCH_MAX_CCH);
	result.resize(GetModuleBaseNameW(GetCurrentProcess(), m_object, &result[0], static_cast<DWORD>(result.size())));
	if (result.empty())
		throw Error("GetModuleBaseNameW");
	return result;
}

void Utils::Win32::LoadedModule::SetPinned() const {
	const auto pModuleHandleAsPsz = reinterpret_cast<LPCWSTR>(m_object);
	HMODULE dummy;
	if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_PIN | GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,
		pModuleHandleAsPsz, &dummy)) {
		throw Error(
			"GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_PIN | GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS, 0x{:x})",
			reinterpret_cast<size_t>(pModuleHandleAsPsz));
	}
}

MODULEINFO Utils::Win32::LoadedModule::ModuleInfo() const {
	MODULEINFO res;
	if (!GetModuleInformation(GetCurrentProcess(), m_object, &res, sizeof res))
		throw Error("GetModuleInformation");
	return res;
}
